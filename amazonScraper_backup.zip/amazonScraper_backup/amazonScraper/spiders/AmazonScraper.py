import scrapy 
from ..items import AmazonscraperItem
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import Rule

class AmazonScrapy(scrapy.Spider):
    name = "amazon"

    #samsung
    start_urls = [
        #"https://www.amazon.in/s?bbn=1389432031&rh=n%3A1389432031%2Cp_89%3ASamsung&dc&qid=1674494969&rnid=3837712031&ref=lp_1389432031_nr_p_89_0"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3AOnePlus&dc&qid=1674637882&rnid=3837712031&ref=sr_nr_p_89_2&ds=v1%3AsxAm2Jk2zjgbRinMbml9FIVJ5LckOVRTnibw5dQv6kw"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3ARedmi&dc&qid=1674638317&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3AaKy1gCk7Gva13BBjiTyBfMfrSRelXs2svbK4OQHwoFc"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3AXiaomi&dc&qid=1674638388&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3A6Mevz%2Fn60S%2Fc7pi46SrWXajyhsZUs5DqfGTEvGmmFRw"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3ATecno&dc&qid=1674638615&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3Ab58DryqoyfMm8Oc5XNu2GjYTjku%2FYGzKhT3y2WBeAng"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3AApple%7CLava%7CMoto%7CNokia%7COnePlus%7COppo%7CPOCO%7CRedmi%7CSamsung%7CTecno%7CXiaomi%7CiQOO&dc&qid=1674638738&rnid=3837712031&ref=sr_nr_p_89_12&ds=v1%3ArESJhxATJqbtPWCowR6re0Bb8qrXAGL4iyMIB3NBzJw"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3AiQOO&dc&qid=1674644111&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3AscJyBmFuXaHO3bOcO%2BB2xX1mAPFzrsF3LrQfWziZMM4"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3ANokia&dc&qid=1674644183&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3AJBr52dJpf8Jfro97Xa17v27cSZ22GiyxEcGhm6mRJUQ"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3AOppo&dc&qid=1674644292&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3AlqqRJ3HMHzUtsWXqOqBRUVw0HlfxdqnbOGh1AXiAn5M"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3AApple&dc&qid=1674644543&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3AgG70%2BXyQjx48EJwM5TPMVUJE8SOIbhaSQZX5N5ZUgwg"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3ALava&dc&qid=1674644648&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3ApE4ygrqRJrLDWDZW6NG3VeCeHVlmSCbEvi4J0lxI43M"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3AMoto&dc&qid=1674644737&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3AdW0QEMgHlf0yRj3B%2Bm9LbfhC1C5CzNS4TSk%2BYXsP8fM"
        #"https://www.amazon.in/s?i=electronics&bbn=1389432031&rh=n%3A1389432031%2Cp_89%3APOCO&dc&qid=1674644827&rnid=3837712031&ref=sr_nr_p_89_1&ds=v1%3AtzkpkjKvi16KDEj72wvPvRyJPKsIFGEQ4oS%2B5q%2B5ejE"
        ]


    def parse(self, response):
        items = AmazonscraperItem()
        for data in response.css('.sg-col-4-of-24.sg-col-4-of-12.s-result-item.s-asin.sg-col-4-of-16.sg-col.s-widget-spacing-small.sg-col-4-of-20'):
            title    = data.css('.a-size-base-plus.a-color-base.a-text-normal::text').extract()
            price    = data.css('.a-price-whole::text').extract()
            rating   = data.css('.a-icon-alt::text').extract()
            sold     = data.css('.a-size-base.s-underline-text::text').extract()
            discount = data.css('.a-letter-space+ span::text').extract()
    

            items['title']    = title
            items['price']    = price
            items['rating']   = rating
            items['sold']     = sold
            items['discount'] = discount
      
            
            yield items

            next_page = response.css('.s-pagination-separator::attr(href)').get()

            if next_page is not None:
                yield response.follow(next_page, callback= self.parse)
